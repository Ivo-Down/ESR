#!/bin/bash

javac -cp ".:./json.jar" *.java
exec bash


