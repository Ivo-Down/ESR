#!/bin/bash

export DISPLAY=:0.0

cd ..

cd ..
cd /tmp/pycore.*

exec bash


